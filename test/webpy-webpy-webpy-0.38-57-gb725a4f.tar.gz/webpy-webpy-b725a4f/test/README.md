# web.py unit tests

## Setup

All databases expect a database with name `webpy` with username `scott` and password `tiger`.

## Running all tests

To run all tests:

    $ python test/alltests.py

## Running individual tests

To run all tests in a file:

    $ python test/db.py

To run all tests in a class:

    $ python test/db.py SqliteTest

To run a single test:

    $ python test/db.py SqliteTest.testUnicode


